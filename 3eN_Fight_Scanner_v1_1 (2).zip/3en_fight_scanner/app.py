from __future__ import annotations

import hashlib
import json
import os
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Any

import requests
from flask import Flask, jsonify, render_template, request

APP_NAME = "3eN Fight"
ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
DATA_DIR.mkdir(exist_ok=True)
REPORT_FILE = DATA_DIR / "reports.json"
CONFIG_FILE = ROOT / "config.json"

DEFAULT_CONFIG = {
    "discord_webhook_url": "",
    "scan_roots": [],
    "max_files": 20000,
    "max_file_size_mb": 150,
    "include_windows_temp": False
}

# These are heuristic filename/path indicators only, not proof of cheating.
SUSPICIOUS_TERMS = (
    # User-provided cheat/menu/loader/spoofer indicators. These are names only,
    # and matches must be reviewed manually.
    "eulen", "menyo", "tiago", "tiago modz", "taigomodz", "falloutmenu",
    "cobramenu", "lux", "lux menu", "dopamine menu", "lua menu", "phantom",
    "monstermenu", "chiken's menu", "mysterious", "zentrix", "lambda",
    "lamda", "vmenu", "fivesense_v2", "swoopiexyz fivem", "kekhack",
    "nitwit", "rely", "nove store", "redengine", "red engine", "mod menu.rar",
    "hack_fivem", "fivem mod menu", "mod gta", "modz gta", "fivem esp",
    "fivem wallhack", "fivem cheat no ban", "hack", "0x32", "sleezy spoofer",
    "aura spoofer", "escape service hack", "hazar", "fivemock", "loey",
    "duk_3", "ad movement", "filter key", "scod", "cr-fastrun", "loader.cfg",
    "loader.prod", "loader.global", "loader", "launcher", "injector",
    "lua injector", "lua executor", "gh injector x64", "gh injector",
    "gh enjector", "extreme injector", "winject", "asi plugin bypass",
    "cheat engine", "cheatengine", "cheat .rar", "ali_unban_method.pdf",
    "unknowncheats", "dumper", "decrypter", "bypass", "resource blocker",
    "memeproj.global", "loading.global", "rxexv3", "cff", "hjaldrgo",
    "ice breaker", "popstar", "lovex",
    # Mods / weapon / movement indicators
    "zc-firerate", "zc-mp_f_freemode", "zc-explosiveammo", "zc-pedlight",
    "zc-electricammo", "zc-pedabilities v3", "zc-increasedrange",
    "zc-weaponmodifier", "zc-infiniteammo", "zc-damageboost",
    "zc-bulletpenetration", "no_recoil.rpf", "ladders.meta", "remove_roll.rpf",
    "aml.lua", "fast_playboi_mods", "pedaccuracy.meta", "weaponcomponents.meta",
    "weaponanimation.meta", "bsk_skills.rpf", "quickenter.rpf"
)

TARGET_DIRS = (
    Path(os.getenv("LOCALAPPDATA", "")) / "FiveM" / "FiveM.app",
    Path(os.getenv("APPDATA", "")) / "CitizenFX",
    Path(os.getenv("LOCALAPPDATA", "")) / "FiveM",
)

app = Flask(__name__)

def load_config() -> dict[str, Any]:
    if not CONFIG_FILE.exists():
        CONFIG_FILE.write_text(json.dumps(DEFAULT_CONFIG, indent=2), encoding="utf-8")
    try:
        config = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        config = {}
    merged = DEFAULT_CONFIG.copy()
    merged.update(config if isinstance(config, dict) else {})
    return merged

def load_reports() -> list[dict[str, Any]]:
    if not REPORT_FILE.exists():
        return []
    try:
        value = json.loads(REPORT_FILE.read_text(encoding="utf-8"))
        return value if isinstance(value, list) else []
    except (OSError, json.JSONDecodeError):
        return []

def save_reports(reports: list[dict[str, Any]]) -> None:
    REPORT_FILE.write_text(json.dumps(reports[-100:], indent=2, ensure_ascii=False), encoding="utf-8")

def sha256_file(path: Path, max_bytes: int) -> str | None:
    try:
        if path.stat().st_size > max_bytes:
            return None
        digest = hashlib.sha256()
        with path.open("rb") as stream:
            for block in iter(lambda: stream.read(1024 * 1024), b""):
                digest.update(block)
        return digest.hexdigest()
    except (OSError, PermissionError):
        return None

def configured_roots(config: dict[str, Any]) -> list[Path]:
    roots = list(TARGET_DIRS)
    for raw in config.get("scan_roots", []):
        if isinstance(raw, str) and raw.strip():
            roots.append(Path(os.path.expandvars(os.path.expanduser(raw.strip()))))
    if config.get("include_windows_temp"):
        roots.append(Path(os.getenv("TEMP", "")))
    unique = []
    seen = set()
    for p in roots:
        try:
            key = str(p.resolve()).lower()
        except OSError:
            key = str(p).lower()
        if key and key not in seen and p.exists() and p.is_dir():
            seen.add(key)
            unique.append(p)
    return unique

def scan_device() -> dict[str, Any]:
    config = load_config()
    max_files = max(100, min(int(config.get("max_files", 20000)), 100000))
    max_bytes = max(1, min(int(config.get("max_file_size_mb", 150)), 2048)) * 1024 * 1024
    roots = configured_roots(config)
    started = datetime.now().astimezone().isoformat(timespec="seconds")
    findings: list[dict[str, Any]] = []
    scanned = 0
    skipped_large = 0
    errors = 0
    visited = set()

    for root in roots:
        for folder, dirs, names in os.walk(root, topdown=True):
            # Avoid traversing reparse-like junctions and hidden system areas where possible.
            dirs[:] = [d for d in dirs if d.lower() not in {"crashdumps", "logs_old"}]
            for name in names:
                if scanned >= max_files:
                    break
                path = Path(folder) / name
                try:
                    resolved = str(path.resolve()).lower()
                    if resolved in visited:
                        continue
                    visited.add(resolved)
                    stat = path.stat()
                    if not path.is_file():
                        continue
                    scanned += 1
                    if stat.st_size > max_bytes:
                        skipped_large += 1
                        continue
                    lower = str(path).lower()
                    matched = [term for term in SUSPICIOUS_TERMS if term in lower]
                    special_notes = []
                    # This size rule is user-configured guidance, not an authoritative
                    # GTA/FiveM baseline; different game versions can legitimately differ.
                    if path.name.lower() == "x64a.rpf":
                        expected_bytes = int(47.566 * 1024 * 1024)
                        tolerance_bytes = 1024 * 1024  # 1 MiB tolerance for unit/rounding differences
                        if abs(stat.st_size - expected_bytes) > tolerance_bytes:
                            matched.append("x64a.rpf size differs from configured 47.566 MB rule")
                            special_notes.append(
                                "حجم x64a.rpf لا يطابق قاعدة 47.566 MB التي أدخلها المستخدم؛ "
                                "قد يختلف الحجم الطبيعي حسب إصدار اللعبة، لذا تحقّق يدويًا."
                            )
                    digest = sha256_file(path, max_bytes)
                    if matched:
                        findings.append({
                            "path": str(path),
                            "name": path.name,
                            "size_bytes": stat.st_size,
                            "modified": datetime.fromtimestamp(stat.st_mtime).astimezone().isoformat(timespec="seconds"),
                            "sha256": digest,
                            "indicators": matched,
                            "notes": special_notes,
                            "severity": "review"
                        })
                except (OSError, PermissionError):
                    errors += 1
            if scanned >= max_files:
                break

    report = {
        "id": datetime.now().strftime("%Y%m%d-%H%M%S"),
        "created_at": started,
        "device_name": os.environ.get("COMPUTERNAME", "Unknown"),
        "user_name": os.environ.get("USERNAME", "Unknown"),
        "roots": [str(p) for p in roots],
        "scanned_files": scanned,
        "findings_count": len(findings),
        "skipped_large_files": skipped_large,
        "access_errors": errors,
        "limited_by_max_files": scanned >= max_files,
        "findings": findings[:500],
        "note": "Heuristic filename/path matches only. A finding is not proof of cheating; verify manually."
    }
    reports = load_reports()
    reports.insert(0, report)
    save_reports(reports)
    send_discord_summary(report, config.get("discord_webhook_url", ""))
    return report

def send_discord_summary(report: dict[str, Any], webhook_url: str) -> None:
    if not webhook_url or not webhook_url.startswith("https://discord.com/api/webhooks/"):
        return
    embed = {
        "title": "3eN Fight • تقرير فحص الجهاز",
        "description": "نتائج أولية تعتمد على مؤشرات أسماء ومسارات الملفات؛ لا تعتبر إثباتًا نهائيًا.",
        "color": 15158332 if report["findings_count"] else 3066993,
        "fields": [
            {"name": "الجهاز", "value": str(report["device_name"])[:100], "inline": True},
            {"name": "الملفات المفحوصة", "value": str(report["scanned_files"]), "inline": True},
            {"name": "مؤشرات للمراجعة", "value": str(report["findings_count"]), "inline": True},
            {"name": "أخطاء الوصول", "value": str(report["access_errors"]), "inline": True},
            {"name": "معرّف التقرير", "value": report["id"], "inline": True}
        ],
        "footer": {"text": "3eN Fight • لا يتم رفع الملفات نفسها إلى Discord"}
    }
    try:
        requests.post(webhook_url, json={"embeds": [embed]}, timeout=8).raise_for_status()
    except requests.RequestException:
        pass

@app.get("/")
def index():
    reports = load_reports()
    return render_template("index.html", reports=reports[:10], scanning=False)

@app.post("/scan")
def scan():
    # Prevent simultaneous scans in this simple local dashboard.
    if getattr(scan, "running", False):
        return jsonify({"error": "الفحص يعمل بالفعل"}), 409
    scan.running = True
    try:
        report = scan_device()
        return jsonify({"ok": True, "report": report})
    finally:
        scan.running = False

@app.get("/api/reports")
def api_reports():
    return jsonify(load_reports()[:100])

@app.get("/report/<report_id>")
def report_page(report_id: str):
    report = next((r for r in load_reports() if r.get("id") == report_id), None)
    if not report:
        return "التقرير غير موجود", 404
    return render_template("report.html", report=report)

if __name__ == "__main__":
    print("3eN Fight يعمل محليًا على http://127.0.0.1:5000")
    app.run(host="127.0.0.1", port=5000, debug=False)
